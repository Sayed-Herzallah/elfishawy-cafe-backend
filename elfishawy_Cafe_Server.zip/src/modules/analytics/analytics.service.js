import { orderModel, orderStatuses } from "../../database/model/order.model.js";
import { expenseModel } from "../../database/model/expense.model.js";
import { inventoryModel } from "../../database/model/inventory.model.js";
import { getBusinessDayKey, getBusinessDayRange } from "../../utils/businessDay.js";

/**
 * F2: بناء نطاق زمني اختياري من from/to (أيام تجارية بتوقيت القاهرة).
 * بدون params → يرجع null ويبقى السلوك القديم الكامل (backward-compatible).
 */
const buildPeriodRanges = (query) => {
  const { from, to } = query || {};
  if (!from && !to) return { createdAtRange: null, expenseDateRange: null };
  let createdAtRange = {};
  let expenseDateRange = {};
  if (from) {
    const { start } = getBusinessDayRange(getBusinessDayKey(new Date(from)));
    createdAtRange.$gte = start;
    expenseDateRange.$gte = start;
  }
  if (to) {
    const { end } = getBusinessDayRange(getBusinessDayKey(new Date(to)));
    createdAtRange.$lte = end;
    expenseDateRange.$lte = end;
  }
  return { createdAtRange, expenseDateRange };
};

// =========================== 1) Get KPIs / Stats ===========================
export const getStats = async (req, res, next) => {
  try {
    const { createdAtRange, expenseDateRange } = buildPeriodRanges(req.query);

    // 1. Total Sales Revenue
    const salesAgg = await orderModel.aggregate([
      { $match: { status: orderStatuses.completed, ...(createdAtRange ? { createdAt: createdAtRange } : {}) } },
      { $group: { _id: null, total: { $sum: "$totalAmount" } } },
    ]);
    const totalSales = salesAgg[0]?.total || 0;

    // 2. Completed Orders Count
    const totalOrdersCount = await orderModel.countDocuments({
      status: orderStatuses.completed,
      ...(createdAtRange ? { createdAt: createdAtRange } : {}),
    });

    // 3. Total Expenses (حقل date هو التاريخ التجاري للمصروف)
    const expensesAgg = await expenseModel.aggregate([
      { $match: { ...(expenseDateRange ? { date: expenseDateRange } : {}) } },
      { $group: { _id: null, total: { $sum: "$amount" } } },
    ]);
    const totalExpenses = expensesAgg[0]?.total || 0;

    // 3.1 مشتريات المخزن (فئة inventory) — لفصل التشغيلية عن المشتريات في الـ Dashboard
    const purchasesAgg = await expenseModel.aggregate([
      { $match: { category: "inventory", ...(expenseDateRange ? { date: expenseDateRange } : {}) } },
      { $group: { _id: null, total: { $sum: "$amount" } } },
    ]);
    const totalPurchases = purchasesAgg[0]?.total || 0;

    // 4. Net Profit
    const netProfit = totalSales - totalExpenses;

    // 5. Low Stock Inventory Count
    const lowStockCount = await inventoryModel.countDocuments({
      $expr: { $lte: ["$quantity", "$minLimit"] },
    });

    return res.status(200).json({
      success: true,
      message: "KPI stats retrieved successfully",
      data: {
        totalSales,
        totalOrdersCount,
        totalExpenses,
        totalPurchases,
        netProfit,
        lowStockCount,
      },
    });
  } catch (err) {
    return next(new Error(`Failed to calculate stats: ${err.message}`, { cause: 500 }));
  }
};

// =========================== 2) Get Charts Data ===========================
export const getCharts = async (req, res, next) => {
  try {
    const { createdAtRange, expenseDateRange } = buildPeriodRanges(req.query);

    // 1. Sales Trend over the last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const salesTrend = await orderModel.aggregate([
      {
        $match: {
          status: orderStatuses.completed,
          createdAt: { $gte: thirtyDaysAgo, ...(createdAtRange || {}) },
        },
      },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt", timezone: "Africa/Cairo" } },
          totalSales: { $sum: "$totalAmount" },
          ordersCount: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    // 2. Expense breakdown by category
    const expenseBreakdown = await expenseModel.aggregate([
      {
        $match: { ...(expenseDateRange ? { date: expenseDateRange } : {}) },
      },
      {
        $group: {
          _id: "$category",
          totalAmount: { $sum: "$amount" },
          count: { $sum: 1 },
        },
      },
      { $sort: { totalAmount: -1 } },
    ]);

    // 3. Top 5 Best-Selling Products
    const topProducts = await orderModel.aggregate([
      { $match: { status: orderStatuses.completed, ...(createdAtRange ? { createdAt: createdAtRange } : {}) } },
      { $unwind: "$items" },
      {
        $group: {
          _id: "$items.product",
          quantitySold: { $sum: "$items.quantity" },
          revenueGenerated: { $sum: { $multiply: ["$items.quantity", "$items.price"] } },
        },
      },
      {
        $lookup: {
          from: "Product_Data",
          localField: "_id",
          foreignField: "_id",
          as: "productDetails",
        },
      },
      { $unwind: "$productDetails" },
      { $sort: { quantitySold: -1 } },
      { $limit: 5 },
      {
        $project: {
          _id: 1,
          quantitySold: 1,
          revenueGenerated: 1,
          name: "$productDetails.name",
          price: "$productDetails.price",
        },
      },
    ]);

    return res.status(200).json({
      success: true,
      message: "Charts data retrieved successfully",
      data: {
        salesTrend,
        expenseBreakdown,
        topProducts,
      },
    });
  } catch (err) {
    return next(new Error(`Failed to retrieve charts data: ${err.message}`, { cause: 500 }));
  }
};
